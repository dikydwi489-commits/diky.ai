document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    // Toggle Sidebar
    document.getElementById('open-sidebar').onclick = () => {
        sidebar.classList.add('open');
        overlay.style.display = 'block';
    };

    document.getElementById('close-sidebar').onclick = closeSidebar;
    overlay.onclick = closeSidebar;

    function closeSidebar() {
        sidebar.classList.remove('open');
        overlay.style.display = 'none';
    }

    // Fungsi Kirim Pesan
    window.sendMessage = async () => {
        const text = userInput.value.trim();
        if (!text) return;

        // Bersihkan intro
        if (document.getElementById('intro')) document.getElementById('intro').remove();

        appendMessage('user', text);
        userInput.value = '';
        userInput.style.height = 'auto';

        // Tampilkan animasi ngetik
        const typingId = showTyping();

        try {
            const response = await fetch('chat.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: text })
            });

            const data = await response.json();
            removeTyping(typingId);

            if (data.candidates) {
                const aiResponse = data.candidates[0].content.parts[0].text;
                appendMessage('ai', aiResponse);
            } else {
                appendMessage('ai', "❌ Maaf, ada masalah pada API.");
            }
        } catch (error) {
            removeTyping(typingId);
            appendMessage('ai', "❌ Gagal terhubung ke server PHP.");
        }
    };

    function appendMessage(sender, text) {
        const div = document.createElement('div');
        div.className = `msg ${sender}`;
        div.innerHTML = `
            <div class="avatar">${sender === 'user' ? 'U' : 'D'}</div>
            <div class="bubble">${text.replace(/\n/g, '<br>')}</div>
        `;
        chatBox.appendChild(div);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function showTyping() {
        const id = 'typing-' + Date.now();
        const div = document.createElement('div');
        div.className = 'msg ai';
        div.id = id;
        div.innerHTML = `
            <div class="avatar">D</div>
            <div class="bubble typing-bubble">
                <div class="dot"></div><div class="dot"></div><div class="dot"></div>
            </div>
        `;
        chatBox.appendChild(div);
        chatBox.scrollTop = chatBox.scrollHeight;
        return id;
    }

    function removeTyping(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    sendBtn.onclick = sendMessage;
    userInput.onkeypress = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } };
});
